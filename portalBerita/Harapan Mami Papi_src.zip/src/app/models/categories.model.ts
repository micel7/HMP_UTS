export interface Categories {
  nama: string;
  icon: string;
  color: string;
  jumlahBerita: number;
}


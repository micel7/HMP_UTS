export interface Categories {
  id: number;
  nama_kategori: string;
  icon: string;
  color: string;
  jumlahBerita: number;
}

